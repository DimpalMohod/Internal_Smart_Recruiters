package net.javaguides.springboot;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ResponsetoPLRepository extends JpaRepository<ResponsetoPL, Integer> {
	List<ResponsetoPL> findByRid(int rid);
	List<ResponsetoPL>findByResid(int resid);
}
