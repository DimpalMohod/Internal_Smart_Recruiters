package net.javaguides.springboot;



import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/")
public class homeAction {
	
	@Autowired
	ProjectleadRepository projectleadRepository; 
	
	@Autowired
	UserRepository userRepository;

	@GetMapping("home")
	public ModelAndView showhome()
	{
		ModelAndView mv=new ModelAndView("Home");
				return mv;
	}
	
	@GetMapping("about")
	public ModelAndView showabout()
	{
		ModelAndView mv=new ModelAndView("About");
				return mv;
	}
	
	
	@GetMapping("reg")
	public ModelAndView showRegister() {
		ModelAndView mv=new ModelAndView("Register");
		return mv;
	}
	//create
		@PostMapping("registered")
		public ModelAndView create(String username,String password,String email,String mobile) {
			ModelAndView mv=new ModelAndView("RegisterMsg");
			
			
			ProjectLead p=new ProjectLead(username,password,email,mobile);
			projectleadRepository.save(p);
			return mv;
		}
		
		
		@GetMapping("/login")
		public ModelAndView log() {
			ModelAndView mv=new ModelAndView("Login");
			return mv;
		}
		
		
		
		 @RequestMapping(value="/Authentlogin" ,method=RequestMethod.POST) 
		public ModelAndView Authenticate(String email,String password) {
			
			/*
			 * HttpSession httpSession=req.getSession();
			 * httpSession.setAttribute("my-admin",1);
			 */
			 
			ProjectLead projectlead=projectleadRepository.findByEmailAndPassword(email, password);
			
			if(projectlead!=null) {
				ModelAndView mv=new ModelAndView("Appointment");
				mv.addObject("projectlead", projectlead);
			
				return mv;
			}
			
			else {
				/*Spring MVC gives special class Model And View which can hold two things 1.view-name and 2.data
				 * we can  add multiple data as per requirement by using add object
				 * 
				 * */
				ModelAndView mv=new ModelAndView("Login");
				mv.addObject("projectlead", projectlead); //sending key & data(Model)
			mv.addObject("q", 1);
	         return mv;
			}
		}
		 
		 
		 @RequestMapping(value="/infolistaftersend" ,method=RequestMethod.POST) 
			public ModelAndView Verify(String id, String resid) {
				int canid=Integer.parseInt(id);
				int hireid=Integer.parseInt(resid);
				
				ProjectLead projectlead=projectleadRepository.findById(canid);
				Hire hire=userRepository.findById(hireid).get(); 
	
				
		
				
				if(projectlead!=null) {
					ModelAndView mv=new ModelAndView("welcome");
					mv.addObject("projectlead", projectlead);
					mv.addObject("hire", hire);
					/* mv.addObject("LIST", 1); */
					return mv;
				}
				
				else {
					ModelAndView mv=new ModelAndView("Login");
					mv.addObject("projectlead", projectlead);
				mv.addObject("q", 1);
		         return mv;
				}
			}
		 
		 
		 
		 
		
		
		
		
		@PostMapping("update-opt")
		public ModelAndView patientUpdateOpt(String email,String password) {
			
			
			ProjectLead projectlead=projectleadRepository.findByEmailAndPassword(email, password);
			System.out.println("lead" +projectlead.getUsername()+" "+projectlead.getPassword());
			if(projectlead!=null) {
				ModelAndView mv=new ModelAndView("Appointment");
				mv.addObject("projectlead", projectlead);
				mv.addObject("u", 2);
				return mv;
			}
			
			else {
				ModelAndView mv=new ModelAndView("Appointment");
		         mv.addObject("u", 0);
	         return mv;
			}
		}
		
	     @PostMapping("upd-patient")
	     public ModelAndView patientupdated(String ide, String username,String email,String mobile) {
	    	  int id=Integer.parseInt(ide);
	    
	    	  
	    	  ProjectLead projectlead=projectleadRepository.findById(id);
	  		
	  		if(projectlead!=null) {
	  			projectlead.setId(id);
	  			projectlead.setUsername(username);
	  			projectlead.setEmail(email);
	  			projectlead.setMobile(mobile);
	  			
	  			projectleadRepository.save(projectlead);
	  			
	  			ModelAndView mv=new ModelAndView("Appointment");
	  			mv.addObject("projectlead", projectlead);
	  			mv.addObject("u", 1);
	  			return mv;
	  		}
	  		
	  		else {
	  			ModelAndView mv=new ModelAndView("message");
	  		 mv.addObject("sendvalue","user not found for below username & password");
	           return mv;
	  		}
	    	  
	    	  
	     }
	     
	 
	  
			
		
		
		
}
