package net.javaguides.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/")
public class ForgotpasswardAction {
	@Autowired
	ProjectleadRepository projectleadRepository;
	
	
	@Autowired
	HrRepository hrRepository;
	
	@GetMapping("FpPL")
	public ModelAndView showhome()
	{
		ModelAndView mv=new ModelAndView("FpPL");
				return mv;
	}
	
	@PostMapping("ForgetPassword")
    public ModelAndView ForgetPassword(String femail, String fpassword) {

   String email=femail;
   	ProjectLead projectlead=projectleadRepository.findByEmail(email);
	System.out.println("lead" +projectlead.getUsername()+" ");
	if(projectlead!=null) {
		projectlead.setEmail(email);
		projectlead.setPassword(fpassword);
		projectleadRepository.save(projectlead);
		ModelAndView mv=new ModelAndView("Login");
		mv.addObject("projectlead", projectlead);
		mv.addObject("hi", 1);

		return mv;
	}
	
	else {
		ModelAndView mv=new ModelAndView("Login");
         mv.addObject("u", 0);
     return mv;
	}

	}
	@GetMapping("FpHR")
	public ModelAndView showhome1()
	{
		ModelAndView mv=new ModelAndView("FpHR");
				return mv;
	}
	
	@PostMapping("ForgetPasswordhr")
    public ModelAndView ForgetPasswordhr(String hrfemail, String hrfpassword) {

   String hremail=hrfemail;
   Hr hr1=hrRepository.findByHremail(hremail);
	/* System.out.println("lead" +projectlead.getUsername()+" "); */
	if(hr1!=null) {
		hr1.setHremail(hremail);
		hr1.setHrpassword(hrfpassword);
		hrRepository.save(hr1);
		ModelAndView mv=new ModelAndView("hr-login");
		mv.addObject("hr1", hr1);
		mv.addObject("hi", 1);

		return mv;
	}
	
	else {
		ModelAndView mv=new ModelAndView("hr-login");
         mv.addObject("u", 0);
     return mv;
	}



	}
}
