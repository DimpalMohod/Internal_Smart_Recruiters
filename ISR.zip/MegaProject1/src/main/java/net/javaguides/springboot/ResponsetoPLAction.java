package net.javaguides.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("/")
public class ResponsetoPLAction {
	
	
	@Autowired
	ProjectleadRepository projectleadRepository ;
	@Autowired
	EmailSenderService emailSenderService;
	
	@Autowired
	ResponsetoPLRepository responsetoPLRepository;
	@Autowired
	UserRepository	userRepository;
	
	@RequestMapping(value="/requested2" ,method=RequestMethod.POST)
	public ModelAndView create2(String resid, String resusername, String resemail, String resmobile, String resskillset,
			String resexperience, int rid)
	{
		try {
		int projectid=rid;
		ProjectLead projectLead= projectleadRepository.findById(projectid);
	
		int plid=Integer.parseInt(resid); 
		ResponsetoPL p1=new ResponsetoPL(plid, resusername, resemail,  resmobile,  resskillset,
			 resexperience, rid );
		responsetoPLRepository.save(p1);
		/* mv.addObject("q", "1"); */
		
		
		  emailSenderService.sendSimpleEmail(projectLead.getEmail(),
		 "Welcome To Internal Smart Recruiters,\n\nYour Request has been fulfilled and we are providing you with a new candidate having required skills.\r\n"
		 
		 +" \nName of Candiate: " +resusername + " \nGmail: " + resemail +"\nMobile: "
		 +resmobile + "\nSkill Set: " +resskillset +"\nExperience: " +resexperience ,
		 "\n From,\n Internal Smart Recruiter!!!");
	 System.out.println("gmail" +projectLead.getEmail());
	 
	Hire hire=userRepository.findById(plid).get();
	userRepository.delete(hire);
	 ModelAndView mv = new ModelAndView("Success_Reg");
		
		/*
		 * List<Hire> reslist = userRepository.findAll(); mv.addObject("reslist",
		 * reslist); mv.addObject("INFOLIST", 1);
		 */
		
       return mv;
	
	}
	catch(Exception e)
		{
		
ModelAndView mv = new ModelAndView("ResponseHr");
		
		List<Hire> reslist = userRepository.findAll();
		mv.addObject("reslist", reslist);
		mv.addObject("INFOLIST", 1);
		mv.addObject("r", "1");
		return mv;
		}
		
	}
	  @PostMapping("abc") 
	  public ModelAndView hrsList1(int rid) {
	  System.out.println(rid +"abc");
	  
	  ModelAndView mv=new ModelAndView("ResponseFromManager"); 
	  List<ResponsetoPL>reshrlist=responsetoPLRepository.findByRid(rid); 
	  System.out.println(reshrlist+"abc..........");
	  mv.addObject("reshrlist", reshrlist);
	 mv.addObject("HrLIST", 1); 
	 return mv; 
	 }
	
	/*
	 * @GetMapping("requestListhr11")
	 * 
	 * public ModelAndView newShow() { ModelAndView mv =new
	 * ModelAndView("welcome1"); List<ResponsetoPL>
	 * responsetoPLok=responsetoPLRepository.findAll();
	 * mv.addObject("responsetoPLok", responsetoPLok); mv.addObject("HrLIST", 1);
	 * return mv; }
	 */

}
