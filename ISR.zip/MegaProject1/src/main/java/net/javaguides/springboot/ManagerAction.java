package net.javaguides.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class ManagerAction {

	@Autowired
	ProjectManagerRepository projectManagerRepository;
	@Autowired
	RequestRepository requestRepository;
   @Autowired
   ProjectleadRepository projectleadRepository;
   @Autowired
   HrRepository hrRepository;
   @Autowired
   ResponsetoPLRepository responsetoPLRepository;
	
	@GetMapping("/mlogin")
	public ModelAndView log() {
		ModelAndView mv = new ModelAndView("ProjectManagerLogin");
		return mv;
	}

	@GetMapping("mregister")
	public ModelAndView showRegister() {
		ModelAndView mv = new ModelAndView("mregister");
		return mv;
	}

	// create
	@PostMapping("mregistered")
	public ModelAndView create(String mname, String mpassword, String memail, String mmobile) {
		ModelAndView mv = new ModelAndView("mregister");

		ProjectManagerLogin p = new ProjectManagerLogin(mname, mpassword, memail, mmobile);
		projectManagerRepository.save(p);
		return mv;
	}

	@RequestMapping(value = "/mAuthentlogin", method = RequestMethod.POST)
	public ModelAndView Authenticate(String memail, String mpassword) {

		ProjectManagerLogin projectmanager = projectManagerRepository.findByMemailAndMpassword(memail, mpassword);
		System.out.println("Check check");
		if (projectmanager != null) {
			ModelAndView mv = new ModelAndView("managerprofile");
			mv.addObject("projectmanager", projectmanager);

			return mv;
		}

		else {
			ModelAndView mv = new ModelAndView("ProjectManagerLogin");
			mv.addObject("projectmanager", projectmanager);
			mv.addObject("q", 1);
			return mv;
		}
	}

	@PostMapping("mupdate")
	public ModelAndView mUpdate(String memail, String mpassword) {

		ProjectManagerLogin projectmanager = projectManagerRepository.findByMemailAndMpassword(memail, mpassword);

		if (projectmanager != null) {
			ModelAndView mv = new ModelAndView("managerprofile");
			mv.addObject("projectmanager", projectmanager);
			mv.addObject("u", 2);
			return mv;
		}

		else {
			ModelAndView mv = new ModelAndView("managerprofile");
			mv.addObject("u", 0);
			return mv;
		}
	}

	@PostMapping("updmanager")
	public ModelAndView patientupdated(String idee, String mname, String memail, String mmobile) {
		int id = Integer.parseInt(idee);

		ProjectManagerLogin projectmanager = projectManagerRepository.findByMid(id);

		if (projectmanager != null) {
			projectmanager.setMid(id);
			projectmanager.setMname(mname);
			projectmanager.setMemail(memail);
			projectmanager.setMmobile(mmobile);

			projectManagerRepository.save(projectmanager);

			ModelAndView mv = new ModelAndView("managerprofile");
			mv.addObject("projectmanager", projectmanager);
			mv.addObject("u", 1);
			return mv;
		}

		else {
			ModelAndView mv = new ModelAndView("message");
			mv.addObject("sendvalue", "user not found for below username & password");
			return mv;
		}

	}
	@GetMapping("pllList")
	  public ModelAndView plList() {				
		
		ModelAndView mv=new ModelAndView("Pllist");	
		List<ProjectLead> pllist=projectleadRepository.findAll();
		mv.addObject("pllist", pllist);
		mv.addObject("PLLIST", 1);
	    return mv;
	  }

	
	@GetMapping("hrlList")
	  public ModelAndView hrList() {				
		
		ModelAndView mv=new ModelAndView("hrlist");	
		List<Hr> hrlist=hrRepository.findAll();
		mv.addObject("hrlist", hrlist);
		mv.addObject("HRLIST", 1);
	    return mv;
	  }
	
	@PostMapping("/delinfolist3")
	public ModelAndView deleteinfolist3(String id) {
		ModelAndView mv = new ModelAndView("Pllist");
		/* String strid = id; */
		int reid = Integer.parseInt(id);
		System.out.println(reid);
		ProjectLead dr = projectleadRepository.findById(reid);
		projectleadRepository.delete(dr);
		List<ProjectLead> pllist = projectleadRepository.findAll();
		mv.addObject("pllist", pllist);
		mv.addObject("PLLIST", 1);
		System.out.println("Candidate deleted successfully ");
		return mv;
	}

	
	@PostMapping("/delinfolist4")
	public ModelAndView deleteinfolist4(String id) {
		ModelAndView mv = new ModelAndView("hrlist");
		/* String strid = id; */
		int reid = Integer.parseInt(id);
		System.out.println(reid);
		Hr dr = hrRepository.findById(reid);
		hrRepository.delete(dr);
		List<Hr> hrlist = hrRepository.findAll();
		 mv.addObject("hrlist", hrlist); 
	 mv.addObject("HRLIST", 1); 
		System.out.println("Candidate deleted successfully ");
		return mv;
	}
	
	
	@PostMapping("/delinfolist5")
	public ModelAndView deleteinfolist5(String id,String resid) {
		ModelAndView mv = new ModelAndView("updatelistofResponse");
		/* String strid = id; */
		int reid1 = Integer.parseInt(resid); 
		int rid = Integer.parseInt(id); 
		/* System.out.println(reid); */
		ResponsetoPL dr = responsetoPLRepository.findById(reid1).get();
		responsetoPLRepository.delete(dr);
		  List<ResponsetoPL>reshrlist=responsetoPLRepository.findByRid(rid); 
		  System.out.println(reshrlist+"abc..........");
		  mv.addObject("reshrlist", reshrlist);
		 mv.addObject("HrLIST", 1); 
		System.out.println("Candidate deleted successfully ");
		return mv;
	}
	
	
}
