package net.javaguides.springboot;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class ResquestFromManger {
	
	@Id

	private int reqid;
	@Column(nullable = false)
	private String technology;
	@Column(nullable = false)
	private String exp;
	@Column(nullable = false)
	private String sdate;
	@Column(nullable = false)
	private String edate;
	public ResquestFromManger() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResquestFromManger(int reqid, String technology, String exp, String sdate, String edate) {
		super();
		this.reqid = reqid;
		this.technology = technology;
		this.exp = exp;
		this.sdate = sdate;
		this.edate = edate;
	}
	public int getReqid() {
		return reqid;
	}
	public void setReqid(int reqid) {
		this.reqid = reqid;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getExp() {
		return exp;
	}
	public void setExp(String exp) {
		this.exp = exp;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}

	
	
	
}
