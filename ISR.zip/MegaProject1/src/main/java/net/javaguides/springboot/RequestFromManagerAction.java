package net.javaguides.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class RequestFromManagerAction {
	
	
	@Autowired
	RequestFromManagerRepository requestFromManagerRepository;
	@Autowired
	RequestRepository 	requestRepository;
	
	@RequestMapping(value="/requested1" ,method=RequestMethod.POST)
	public ModelAndView create1(String reqid, String technology, String exp, String sdate, String edate) {
		
		int plid=Integer.parseInt(reqid);
		ResquestFromManger p1=new ResquestFromManger(plid ,technology,  exp, sdate,edate );
		requestFromManagerRepository.save(p1);
		ModelAndView mv = new ModelAndView("Success_Reg");
		/*
		 * List<RequestFromPL> reqlist = requestRepository.findAll();
		 * mv.addObject("reqlist", reqlist); mv.addObject("DRLIST", 1);
		 * mv.addObject("q", "1");
		 */
       return mv;
	}
		
	@GetMapping("requestListhr")
	  public ModelAndView drList() {				
		
		ModelAndView mv=new ModelAndView("RequestfromManager");	
		List<ResquestFromManger> reqhrlist=requestFromManagerRepository.findAll();
		mv.addObject("reqhrlist", reqhrlist);
		mv.addObject("HrLIST", 1);
	    return mv;
	  }
	
	
	
	@PostMapping("/delinfolist1")
	public ModelAndView deleteinfolist(String resid) {
		ModelAndView mv = new ModelAndView("RequestfromManager");
		String strid = resid;
		int reid = Integer.parseInt(strid);
		System.out.println(resid);
		ResquestFromManger dr = requestFromManagerRepository.findById(reid).get();
		requestFromManagerRepository.delete(dr);
		List<ResquestFromManger> reqhrlist = requestFromManagerRepository.findAll();
		mv.addObject("reqhrlist", reqhrlist);
		mv.addObject("HrLIST", 1);
		System.out.println("Candidate deleted successfully ");
		return mv;
	}

}
