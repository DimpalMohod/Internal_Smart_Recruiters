package net.javaguides.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/")
public class poolHireAction {

	@Autowired
	poolHireRepository PoolHireRepository;
	@Autowired
	ResponsetoPLRepository responsetoPLRepository;
	@Autowired
	ProjectleadRepository projectleadRepository;
	
	@Autowired
	EmailSenderService emailSenderService;
	
	
	@GetMapping("poolList")
	  public ModelAndView poolList() {				
		
		ModelAndView mv=new ModelAndView("poolList");	
		List<poolHire> poollist=PoolHireRepository.findAll();
		mv.addObject("poollist", poollist);
		mv.addObject("INFOLIST", 1);
	    return mv;
	  }
	
	
	
		
		 @PostMapping("poolList1") public ModelAndView poolList1(String resskillset) {
		 
		 ModelAndView mv=new ModelAndView("poolList"); 
		 List<poolHire>poollist=PoolHireRepository.findByResskillset(resskillset);
		  mv.addObject("poollist", poollist);
		  mv.addObject("INFOLIST", 1); 
		  return mv;
		  }
		 
		 
		 
			@RequestMapping(value="/requested3" ,method=RequestMethod.POST)
			public ModelAndView create2(String resid, String resusername, String resemail, String resmobile, String resskillset,
					String resexperience, int rid)
			{
				try {
				int id=rid;
				 ProjectLead projectLead= projectleadRepository.findById(id); 
				ModelAndView mv=new ModelAndView("Success_Reg");
				int plid=Integer.parseInt(resid); 
				ResponsetoPL p1=new ResponsetoPL(plid, resusername, resemail,  resmobile,  resskillset,
					 resexperience, rid );
				responsetoPLRepository.save(p1);
				mv.addObject("q", "1");
				
			
				  emailSenderService.sendSimpleEmail(projectLead.getEmail(),
						  "Welcome To Internal Smart Recruiters,\n\nYour Request has been fulfilled and we are providing you with a new candidate having required skills.\r\n"
							 
		 +" \nName of Candiate: " +resusername + " \nGmail: " + resemail +"\nMobile: "
		 +resmobile + "\nSkill Set: " +resskillset +"\nExperience: " +resexperience ,
		 "\n From,\n Internal Smart Recruiter!!!");
						 System.out.println("gmail" +projectLead.getEmail());
						 
						 poolHire PoolHire=PoolHireRepository.findById(plid).get();
						 PoolHireRepository.delete(PoolHire);
				
		       return mv;
				}
				catch(Exception e)
				{
					ModelAndView mv=new ModelAndView("poolList");	
					List<poolHire> poollist=PoolHireRepository.findAll();
					mv.addObject("poollist", poollist);
					mv.addObject("r", 1);
					mv.addObject("INFOLIST", 1);
					return mv;
				}
			}
			
			
			
			@GetMapping("addpool")
			public ModelAndView showRegister1() {
				ModelAndView mv = new ModelAndView("addpoolhireForm");
				return mv;
			}

			
			 @PostMapping("/addpool1") 
			 public ModelAndView createUser(poolHire user) {
			  
				 PoolHireRepository.save(user);
			  
			  ModelAndView mv = new ModelAndView("addpoolhireForm");
			  mv.addObject("q","1"); 
			  return mv; }
			 

		 
}
